
//body
let variavelBody = document.querySelector('body');
console.log(variavelBody);


//h1
let variavelH2 = document.querySelector('h2');
console.log(variavelH2);

//div
let variavelDiv = document.querySelectorAll('div');
console.log(variavelDiv);

//section
let variavelsection = document.querySelector('section');
console.log(variavelsection);